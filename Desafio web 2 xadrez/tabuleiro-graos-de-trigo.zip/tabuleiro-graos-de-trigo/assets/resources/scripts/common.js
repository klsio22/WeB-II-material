/*
	Geral
*/

$(document).ready(function () {
    $(".sidenav").sidenav();
    $('.datepicker').datepicker();
    //$('.collapsible').collapsible();
    $('select').formSelect();
});
