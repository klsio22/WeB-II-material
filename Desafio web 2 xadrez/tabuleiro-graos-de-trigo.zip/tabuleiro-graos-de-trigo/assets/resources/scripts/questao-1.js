(function () {

    //TODO código aqui    

})();
