(function () {

    let $id = function (id) {
        return document.getElementById(id);
    }

})();
